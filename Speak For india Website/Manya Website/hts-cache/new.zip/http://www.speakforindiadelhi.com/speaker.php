<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Speak for India Delhi edition | Vote for the 'Most Populr Speaker'</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/manual.css?v=1.26">
      <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
      <link rel="stylesheet" href="assets/css/owlcarousel/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/owlcarousel/owl.theme.default.min.css">
      <link rel="stylesheet" href="assets/css/bootstrap-responsive.min.css">
      <!-- Google fonts Poppins -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <!-- Fontello -->
      <link rel="stylesheet" href="assets/css/css-fontello/animation.css" type="text/css"/>
      <link rel="stylesheet" href="assets/css/css-fontello/fontello.css" type="text/css"/>
      <link rel="stylesheet" href="assets/css/css-fontello/fontello-codes.css" type="text/css"/>
      <link rel="stylesheet" href="assets/css/css-fontello/fontello-embedded.css" type="text/css"/>
      <link rel="stylesheet" href="assets/css/css-fontello/fontello-ie7.css" type="text/css"/>
      <link rel="stylesheet" href="assets/css/css-fontello/fontello-ie7-codes.css" type="text/css"/>
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="assets/js/respond.min.js"></script>
      <![endif]-->
      <meta property="og:title" content="Venues for Speak for India (Delhi Edition)" />
      <meta property="og:description" content="Venues for Speak for India (Delhi edition), Delhi NCR's biggest debate competition. Speak for India'19 invites entries from college students for debate on the political and social issues of India through compelling public speaking" />
      <meta property="og:url" content="http://www.speakforindiadelhi.com/venue.html" />
      <meta property="og:image" content="http://www.speakforindiadelhi.com/assets/images/about-banner.jpg" />
      <script type="text/javascript"> var _comscore = _comscore || []; _comscore.push({ c1: "2", c2: "6035286" }); (function() { var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true; s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js"; el.parentNode.insertBefore(s, el); })();</script>
      <noscript><img src="http://b.scorecardresearch.com/p?c1=2&c2=6035286&cv=2.0&cj=1" /></noscript>
      <!-- Google Analytics -->
      <script>
         (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
         (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
         m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
         })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
         ga('create', 'UA-1431719-1', 'auto');
         ga('send', 'pageview');
      </script>
      <!-- End Google Analytics -->
      <!-- Facebook Pixel Code -->
      <script>
         !function(f,b,e,v,n,t,s)
         {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
         n.callMethod.apply(n,arguments):n.queue.push(arguments)};
         if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
         n.queue=[];t=b.createElement(e);t.async=!0;
         t.src=v;s=b.getElementsByTagName(e)[0];
         s.parentNode.insertBefore(t,s)}(window, document,'script',
         'https://connect.facebook.net/en_US/fbevents.js');
         fbq('init', '160090851150189');
         fbq('track', 'PageView');
      </script>
      <noscript><img height="1" width="1" style="display:none"
         src="https://www.facebook.com/tr?id=160090851150189&ev=PageView&noscript=1"
         /></noscript>
      <script>
         !function(f,b,e,v,n,t,s)
         {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
         n.callMethod.apply(n,arguments):n.queue.push(arguments)};
         if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
         n.queue=[];t=b.createElement(e);t.async=!0;
         t.src=v;s=b.getElementsByTagName(e)[0];
         s.parentNode.insertBefore(t,s)}(window, document,'script',
         'https://connect.facebook.net/en_US/fbevents.js');
         fbq('init', '359335618005247');
         fbq('track', 'PageView');
      </script>
      <noscript><img height="1" width="1" style="display:none"
         src="https://www.facebook.com/tr?id=359335618005247&ev=PageView&noscript=1"
         /></noscript>
      <!-- End Facebook Pixel Code -->
      <!-- Global site tag (gtag.js) - Google Ads: 877927267 -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=AW-877927267"></script>
      <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         
         gtag('config', 'AW-877927267');
      </script>
      <script>
         (function(p, l, o, w, i, n, g) {
         if (!p[i]) {
         p.GlobalSnowplowNamespace = p.GlobalSnowplowNamespace || [];
         p.GlobalSnowplowNamespace.push(i);
         p[i] = function() {
         (p[i].q = p[i].q || []).push(arguments);
         };
         p[i].q = p[i].q || [];
         n = l.createElement(o);
         g = l.getElementsByTagName(o)[0];
         n.async = 1;
         n.src = w;
         g.parentNode.insertBefore(n, g);
         p['product_id'] = "ht";
         p['platoform'] = "web";
         p['cookieDomain'] = '.hindustantimes.com';
         }
         }(window, document, "script",
         "https://analytics.htmedia.in/analytics-js/htil-analytics.js",
         "snowplow"));
      </script>
      <script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5dd3d8189e304f00123cfadf&cms=sop' async='async'></script>
   </head>
   <body>
      <div class="page speaker">
      <!--=============================== Header ===========================-->
      <!--=============================== Menu-Bar ========================-->
      <div id="menuBar-charity"></div>
      <!--=============================== Banner ==========================-->
      <div class="banner">
         <div class="shadow-main">
            <h1>Vote for the 'Most Popular Speaker' <p>This is your chance to nominate Delhi's most <br/>popular speaker by voting for our finalists</p></h1>
            <ul class="breadcrumb breadcrumb-news">
               <li><a href="index.html">HOME</a></li>
               <li><a href="about-us.html">Speaker</a></li>
            </ul>
         </div>
      </div>
      <div class="main-container-4 mainCont">
	 
         <div class="container">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/ranu.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Ranu Sancheti</h2>
                        <h3>Fore School of Management</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61851" data-name="Ranu Sancheti" ></button>
					
                  </div>
				   <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/manya-arora.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Manya Arora	</h2>
                        <h3>Kirori Mal College</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61852"  data-name="Manya Arora"></button>
					 
                  </div>
				  <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/bharath.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Bisathi Bharath	</h2>
                        <h3>IGNOU</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61853" data-name="Bisathi Bharath"></button>
					
                  </div>
				  <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/Laiba.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Laiba	</h2>
                        <h3>Arjun Singh Jamia Millia Islamia</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61854" data-name="Laiba"></button>
					
                  </div>
				   <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/manawwar-hussain.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Manawwar Hussain	</h2>
                        <h3>Kirori Mal College</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61855" data-name="Manawwar Hussain"></button>
					
                  </div>
				   <span class="msg-vote"></span>
               </div>
           </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/priyanshi.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Priyanshi Sharma	</h2>
                        <h3>Daulat Ram College</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61856" data-name="Priyanshi Sharma"></button>
					
                  </div>
				  <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/vinayak.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Vinayak Gupta</h2>
                        <h3>Hindu College</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn " type="button" id="61857" data-name="Vinayak Gupta"></button>
					 
                  </div>
				  <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               <div class="voter-list">
                  <div class="info">
                     <div class="image-con">
                        <img src="assets/images/sushovan.jpg"  />
                     </div>
                     <div class="v-detail">
                        <h2>Sushovan Chakraborty</h2>
                        <h3>Hindu College</h3>
                     </div>
                  </div>
                  <div class="link-con">
                     <a class="video-link" href="#"></a>
                     <button  class="vote-btn" type="button" id="61858" data-name="Sushovan Chakraborty"></button>
					
                  </div>
				  <span class="msg-vote"></span>
               </div>
            </div><!-- speaker grid -->
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center all-result-text">
	  <p> To view the complete results of the competition, <a class="all-result" href="result.html"> click here.</a></p>
	  </div>
         </div>
         <div id="footer"></div>
      </div>
      <!--  /.page -->
      <!-- JS code -->
      <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script src="assets/js/jquery.spincrement.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/myScript.js"></script>
      <script>
         $( document ).ready(function() {
             $('.vote-btn').click(function(){
				var currentElm = $(this);
         		var voterID = currentElm.attr("id");
         		console.log(voterID);
         		var name = currentElm.attr("data-name");
         		
         		$.post("saveVote.php", {"id":voterID, "name":name}, function (data) {
         
             }).done(function (data) {
               //alert(data);
         	  var res = data.split("^");
         	  if(res[1]=="Y")
         	  {
         		currentElm.parent().next('.msg-vote').html('Thank you for your vote');
         		currentElm.parent().parent().parent().siblings().find('.msg-vote').html('');
				
         	  }
         	  else{
         		 currentElm.parent().next('.msg-vote').html('Sorry, you have already voted for this participant.');
				 currentElm.parent().parent().parent().siblings().find('.msg-vote').html(" ");
				 
         	  }
         		
         		
               
             });
         	})
         });
      </script>
   </body>
</html>